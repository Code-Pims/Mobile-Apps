<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="images/leaderboardcss.css">

	<title>LEADERBOARD</title>
</head>

<style type="text/css">
body {user-select: none;
  background-repeat: no-repeat;
  position: fixed;
	visibility: collapse;
}
.freeze-row {
	border: 1px solid green;
	border-spacing: 0;
}
thead th {
	position: sticky;
	border:1px solid green;
	color: red; 
	background-color: lightgrey;
	top:0;
	z-index: 20;
	text-align: center;
}

  table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  font-size: 12px;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

/* .............................................. */
.firstBox {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
height: 205px;
  font-size: 12px;
overflow: scroll;
}
.secondBox {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
height: 205px;
  font-size: 12px;
overflow: scroll;
}
.thirdBox {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
height: 435px;
  font-size: 12px;
overflow: scroll;
}

/* Scrollbar styles */
::-webkit-scrollbar {
width: 10px;
height: 2px;
}

::-webkit-scrollbar-track {
border: 1px solid yellowgreen;
border-radius: 2px;
}

::-webkit-scrollbar-thumb {
background: yellowgreen;  
border-radius: 2px;
}

::-webkit-scrollbar-thumb:hover {
background: #88ba1c;  
}

/* .............................................. */
/* .............................................. */

/* main input field*/
#mainly nav {
	background: white;
	border: 1px solid gray;
	width: 99%;
	font-size: 20px;
	height: 25px;
	margin-top: 10px;
	line-height: 10px;
}

#mainly nav ul {
	margin-top: -2px;
	margin-left: -50px;
	line-height: 25px;
}

#mainly nav ul li {
	list-style-type: none;
	display: inline-block;
	margin:2px 20px;
}

#mainly nav ul li a {
	cursor: pointer;
	text-decoration: none;
	color: black;
	padding: 2px 10px;
	transition: 0.4s all ease-out;
	font-family: 'Open Sans', sans-serif;
}
.Ranking {margin-top: 100%;}

@media only screen and (max-width:416px) {
		body {
			visibility: visible;
		}
	}

</style>

<body>

	<center>
<div id="MobileSize" > 
	<div><a href="Homepage.php"><i class="fa fa-long-arrow-left" style="font-size:36px;position: absolute; top: 10px; left: 8%; color: black;" ></i></a></div>
	<img src="Images/Head-display.png" alt="Alt" style=" height: 200px; width: 340px;">


	<div class="header" id="myHeader">
		<button class="tablink" onclick="openTable('Ranking', this, 'green')" id="defaultOpen">RANKING</button>
<button class="tablink" onclick="openTable('Leaderboard', this, 'red')">LEADERBOARD</button>
</div><br><br>


<div class="row" style="margin-top: -35px;">
<div id="Ranking" class="tabcontent">
	<h4 class="daily" style="margin: 3px; float: left;">Daily Rankings</h4>
	<div class="firstBox">


        <?php
include('connection.php');

$query = "SELECT * from user order by daily DESC";
$result = $con->query($query);
?>

<table class="freeze-row">
<thead>
  <tr>
    <th style="width:10%;">POS</th>
    <th>EAST</th>
    <th>PTS</th>
  </tr>
</thead>	

<?php
if ($result->num_rows > 0) {
  $id=1;
  while($data = $result->fetch_assoc()) {
 ?>

 <tbody style="text-align: center;">
 <tr>
   <td><?php echo $id++ ?> </td>
   <td><?php echo $data['lastname']; ?>, <?php echo $data['firstname']; ?></td>
   <td><?php echo $data['daily']; ?> </td>
 </tr> 
</tbody>
 <?php
  }} else { ?>
    <tr>
     <td colspan="1">No data found</td>
    </tr>

 <?php } ?>

 </table>
</div>

<h4 class="weekly" style="margin: 3px; float: left;">Weekly Rankings</h4>
	<div class="secondBox">
		
        <?php
include('connection.php');

$query = "SELECT * from user order by weekly DESC";
$result = $con->query($query);
?>

<table class="freeze-row">
<thead>
  <tr>
    <th style="width:10%;">POS</th>
    <th>EAST</th>
    <th>PTS</th>
  </tr>
</thead>	

<?php
if ($result->num_rows > 0) {
  $id=1;
  while($data = $result->fetch_assoc()) {
 ?>

 <tbody style="text-align: center;">
 <tr>
   <td><?php echo $id++ ?> </td>
   <td><?php echo $data['lastname']; ?>, <?php echo $data['firstname']; ?></td>
   <td><?php echo $data['weekly'];  ?> </td>
 </tr> 
</tbody>
 <?php
  }} else { ?>
    <tr>
     <td colspan="1">No data found</td>
    </tr>
 <?php } ?>

 </table> </div>

</div>

<div id="Leaderboard" class="tabcontent">
	<h4 class="Leadboard" style="margin: 3px; float:left;">Leaderboard</h4>

	<div class="thirdBox">

		       <?php
include('connection.php');

$query = "SELECT * from user order by leaderboard DESC";
$result = $con->query($query);
?>

<table class="freeze-row">
<thead>
  <tr>
    <th style="width:10%;">POS</th>
    <th>EAST</th>
    <th>PTS</th>
  </tr>
</thead>	

<?php
if ($result->num_rows > 0) {
  $id=1;
  while($data = $result->fetch_assoc()) {
 ?>

 <tbody style="text-align: center;">
 <tr>
   <td><?php echo $id++ ?> </td>
   <td><?php echo $data['lastname']; ?>, <?php echo $data['firstname']; ?></td>
   <td><?php echo $data['leaderboard']; ?> </td>
 </tr> 
</tbody>
 <?php
  }} else { ?>
    <tr>
     <td colspan="1">No data found</td>
    </tr>

 <?php } ?>

 </table>
</div>

				</div>
			</div>

<!-- Home Buttons -->
<div id="mainly">
	<nav>
	<ul>
					<li><a class="activey" href="Loginform.php"><i class="fa fa-home"></i></a></li>
					<li><a href="#"><i class="fa fa-bar-chart"></i></a></li>
					<li><a href="#"><i class="fa fa-bell"></i></a></li>
					<li><a href="#"><i class="fa fa-fw fa-user"></i></a></li>	
		</ul>
	</nav>
</div>

</div>
</center>

<script>
function openTable(TableName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(TableName).style.display = "block";
  elmnt.style.backgroundColor = color;

}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

</body>
</html>