<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="images/dashboard.css">

	<title>LEADERBOARD</title>
</head>

<body>

	<center>

	<div class="header" id="myHeader">
		<button class="tablink" onclick="openTable('SIGNIN', this, 'green')" id="defaultOpen">SIGN IN</button>
<button class="tablink" onclick="openTable('SIGNUP', this, 'red')">SIGN UP</button>
</div><br><br>


<div class="row" style="margin-top: -35px;">

<div id="SIGNIN" class="tabcontent">
	<h4 class="Signinbtn" style="margin: 3px; float: left;">SIGN IN</h4>
	<div class="firstBox">
		<p>How are you!</p>
	</div>
</div>


<div id="SIGNUP" class="tabcontent">
	<h4 class="Signupbtn" style="margin: 3px; float:left;">SIGN UP</h4>
	<div class="secondBox">
		<p>How are you!</p>
	 </div>

		
		</div>
			</div>

<!-- Home Buttons -->
<footer id="mainly">
	<nav>
	<ul>
					<li><a class="activey" href="Main.php"><i class="fa fa-home"></i></a></li>
					<li><a href="#"><i class="fa fa-bar-chart"></i></a></li>
					<li><a href="#"><i class="fa fa-bell"></i></a></li>
					<li><a href="#"><i class="fa fa-fw fa-user"></i></a></li>	
		</ul>
	</nav>
</footer>

</div>
</center>

<script>
function openTable(TableName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(TableName).style.display = "block";
  elmnt.style.backgroundColor = color;

}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

</body>
</html>