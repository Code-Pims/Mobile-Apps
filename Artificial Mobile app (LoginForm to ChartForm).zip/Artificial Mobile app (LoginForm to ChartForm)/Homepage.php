<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>HOME PAGE</title>
</head>

<style type="text/css">

#MobileSize {
  border: 2px solid black;
  height: 600px;
  width: 340px;
  background-repeat: no-repeat;
  position: relative;
  margin-top: 3%;
  }

  h1 { margin-top:50%; }

</style>


<body>
	<center>
<div id="MobileSize">
	<h1>The Game will Display Here!</h1>

	<a href="Leaderboard.php">Next</a>

</div>
</center>


</body>
</html>