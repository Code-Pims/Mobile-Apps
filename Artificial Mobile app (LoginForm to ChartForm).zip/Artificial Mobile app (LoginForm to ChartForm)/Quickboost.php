
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Montserrat+Alternates:wght@700&display=swap" rel="stylesheet">

  <title>QUICK BOOSTS</title>
</head>

<style type="text/css">
  #MobileSize {
  border: 2px solid black;
  height: 600px;
  width: 340px;
  background-repeat: no-repeat;
  position: relative;
  background-image: url(Images/-Loadpage.png);
  background-size: 350px 550px;
  margin-top: 3%;
  }
  .bottom-right {
  position: absolute;
  bottom: 20px;
  left: 25%;
  color: white;
  cursor: pointer;
}
.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
  cursor: pointer;
}

.Homey {
  text-decoration: none;
  color: White;
  font-family: 'Fredoka One', cursive;
}


</style>

<!-- Game idea, Time frame or specific time the game will start. 
  ** The GAME will activate exactly depend to the time zone (PST).
Kong ang user wala ka apas, automatic sa home page or mag wait until the game ends.
** Automatic Zero points.
** The same as a Bench Player

"Daily and Weekly Points"
** Starting Five - Change the first Five table color to identify their position.
** Leading Five User(Player)

"Leaderboard"
** Starting Five
** Leading Five User(Player)
-->

 <!-- I will this page as waiting room.
  After a few seconds or after the exact time frame the GAME will begin.
  ** Countdown 10seconds
  **And Shake your Phone (accelerometer sensor mobile codes) -->

<body>

<center>
<div id="MobileSize">
<img src="Images/Loadpage.png" alt="Alt">
  <div class="bottom-right">
    <progress value="0" max="5" id="progressBar"></progress>
  </div>
  <div class="centered">
    <a class="Homey" href="Homepage.php"><h2 id="Goow"></h2></a>
  </div>




</div>
</center>

<script>
const myTimeout = setTimeout(StartGame, 7000);

function StartGame() {
  document.getElementById("Goow").innerHTML = "CLICK TO START THE GAME"
}

function myStopFunction() {
  clearTimeout(myTimeout);
}
</script>
<script type="text/javascript">
var timeleft = 5;
var downloadTimer = setInterval(function(){
  if(timeleft <= 0){
    clearInterval(downloadTimer);
  }
  document.getElementById("progressBar").value = 5 - timeleft;
  timeleft -= 1;
}, 1000);
</script>

</body>
</html>