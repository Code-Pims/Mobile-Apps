<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

	<title>Landing Page</title>
</head>

<style type="text/css">
	body {user-select: none;}

#MobileSize {
  border: 2px solid black;
  height: 600px;
  width: 340px;
  background-repeat: no-repeat;
  position: relative;
  margin-top: 3%;
  background-image: url(Images/LOGO.png);
  background-size: 350px 350px;
	}

	#main {
		margin-top: 100%;
		text-align: center;
		margin-right: 40px;
		font-size: 20px;
	}

	#main nav ul li {
	list-style-type: none;
	display: inline-block;
	text-decoration: none;
	line-height: 70px;
}

	.Quick { border: 2px solid green;
		border-radius: 10px;
		text-decoration: none;
		background-color: seagreen;
		color: white;
		padding: 8px 25px; }

	.Quick:hover {border: 2px solid green;
		background-color: red;
		font-weight: bold;
		font-size: 22px;
	}	

	.Team {
		border: 2px solid green;
		border-radius: 10px;
		text-decoration: none;
		padding: 10px;
		margin-top: 10%;
	}
	.Team:hover {border: 2px solid red;
		background-color: Green;
		font-weight: bold;
		color: white;
		font-size: 22px;
	}

	#Exit {
		margin-top:20%;
		background-color: #7E8C95;
	}

	#Exit a i { margin-top: 2%;
		padding: 10px 30px;
		text-decoration: none;}
	



</style>


<body>
<center><div id="MobileSize">

<div id="main">
		<nav><ul>
			<li><a class="Quick" href="Quickboost.php">Quick Boost</a></li><br>
			<li><a class="Team" href="#">Team of League</a></li>
		</ul> </nav>
	</div>

<div id="Exit">
		<a href="#"><i class='fa fa-bars' style='font-size:20px; margin-right: 4%; color: white;'></i></a>
		<a href="Main.php"><i class='fa fa-home' style='font-size:20px; color: white;'></i></a>
		<a href="Main.php"><i class='fas fa-sign-out-alt' style='font-size:20px; color: white;'></i></a>
	</div>

	</div></center>

</body>
</html>